package org.zerock.mapper;

import org.zerock.domain.AdminUserVO;

public interface AdminUserMapper {
    AdminUserVO read(String adminId); // adminId로 사용자 조회
}
